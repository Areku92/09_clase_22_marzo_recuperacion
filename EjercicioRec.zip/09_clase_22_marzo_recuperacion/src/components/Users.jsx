import React, { useState, useEffect } from "react";
import getPeople from "../helpers/getPeople";
import User from "./User";


const initialStateUsers = [];

const Users = () => {
  const [users, setUsers] = useState(initialStateUsers);

  useEffect(() => {
    getActors();
  }, []);

  const getActors = () => {
    getPeople()
      .then((users) => {
        setUsers(users);
      })
      .catch((error) => console.error(error));
  };
  const deleteActor = (index) => {
    if (confirm("Estas seguro de querer eliminar este actor") == true) {
      setUsers(users.filter((user) => user.userId != index));
    } else {
      console.log("No lo has borrado, menos mal ");
    }
  };

  return (
    <>
      {users.map((user) => (
        <div key={user.userId}>
          <User key={user.userId} user={user} />
          <img
            src="https://cdn-icons-png.flaticon.com/512/58/58326.png"
            alt=""
            onClick={() => deleteActor(user.userId)}
          />
        </div>
      ))}
    </>
  );
};

export default Users;
