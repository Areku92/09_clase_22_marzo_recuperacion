import React, { useState, useEffect } from "react";


const User = ({ user }) => {
  return (
    <div>
      <h1>{user.name}</h1>
      <h3>{user.gender}</h3>
      <img
        src={`https://starwars-visualguide.com/assets/img/characters/${user.userId}.jpg`}
        alt=""
      />
    </div>
  );
};

export default User;
