import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import React, { useState, useEffect } from "react";

import "./App.css";
import Users from "./components/Users";



function App() {




  return (
    <div className="App">
     <Users />
      
    </div>
  );
}

export default App;
